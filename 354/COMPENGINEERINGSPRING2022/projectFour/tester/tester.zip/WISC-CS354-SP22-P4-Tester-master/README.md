# CS 354 SP22 Project 4 Sample Tester

This repository automatically tests your project 4 implementation by drivers given before the deadline and written by me. There is no code which can be submitted for this project in this repository.

This repository is not endorsed or created by anyone working in an official capacity with UW-Madison or any staff for CS354. The scripts are made by a student, for students.

By running this repository, you are executing code you downloaded from the internet. Back up your files and take a look at what you are running first.

To run the tests, you should first put your ```mem.h``` and ```mem_functions.c``` in the root directory of the repository folder, and then execute ```test.sh``` within the root directory.
