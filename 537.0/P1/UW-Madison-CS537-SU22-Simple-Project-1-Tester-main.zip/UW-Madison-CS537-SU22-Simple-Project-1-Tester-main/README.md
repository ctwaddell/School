# UW-Madison-CS537-SU22-Simple-Project-1-Tester
This repository automatically tests your my-look implementation by compare your output with output given by look command in Linux. Unfortunately, it can not test with stdin, only with files.

This is NOT an official project tester! The scripts are made by a student, for students. It may not be 100% accurate!!! Passing all tests does not mean your my-look is 100% correct! 

To run the tests, you should first put your my-look.c in the root directory of the repository folder.

Run command   ```chmod +x test.sh```
to give the test.sh permission and then execute test.sh within the root directory.

Remember to run it on the CSL machine!
